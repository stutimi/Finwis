version https://git-lfs.github.com/spec/v1
oid sha256:2b5cc684cdbba2e5fee4d2fdfe8846797c9ae9302d386068b2fe4ee3e2548f8a
size 20316
