version https://git-lfs.github.com/spec/v1
oid sha256:00ac3b7e5d13c3cebec766b9fd900a1cec4db1a99b3aaf10d32156bdd61dade8
size 1575
