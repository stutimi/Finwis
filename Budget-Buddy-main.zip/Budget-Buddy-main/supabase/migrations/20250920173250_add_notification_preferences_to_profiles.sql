version https://git-lfs.github.com/spec/v1
oid sha256:a6837a10c3f8563fa802c7aadeba1ce7ad8c24a7ea29b56d9124deeef9ed0a65
size 283
