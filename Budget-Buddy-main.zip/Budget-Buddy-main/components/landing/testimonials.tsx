"use client";

import { FinancialTestimonials } from "./financial-testimonials";

export function TestimonialsSection() {
  return <FinancialTestimonials />;
}